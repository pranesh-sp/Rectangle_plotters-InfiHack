###############################################################################
Team Mirai - Plotting Algos
###############################################################################


Requirements-

1) Python 3 with tkinter, Pandas, rectangle-packer



Instructions-

1 - Just Replace the file path to appropriate datasets

That's it!  : P

Happy Plotting!!!

###############################################################################